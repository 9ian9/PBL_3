﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class MenuItem
    {
        public string MaMA { get; set; }
        public MenuItem()
        {
        }

        public string TenMA { get; set; }
        public int Calo { get; set; }
        public int DonGia { get; set; }
        public bool Loai { get; set; }
        public string FK_MaDD { get; set; }
        public string FK_MaDM { get; set; }
        public MenuItem(string tenma, int calo, int dongia, bool loai)
        {
            this.TenMA = tenma;
            this.Calo = calo;
            this.DonGia = dongia;
            this.Loai = loai;

            /* this.mama = mama;
             this.tenma = tenma; 
             this.calo = calo;   
             this.dongia = dongia;
             this.fk_MaDD = fk_MaDD;
             this.fk_MaDM= fk_MaDM;
            */
        }
    }
}
