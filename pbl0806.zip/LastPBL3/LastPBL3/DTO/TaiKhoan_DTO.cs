﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TaiKhoan_DTO
    {
        public string MaTK;
        public string TaiKhoan;
        public string MatKhau;
        public int FK_MaQuyen;
        public string matk
        {
            get
            {
                return MaTK;
            }
            set
            {
                MaTK = value;
            }
        }
        public string taikhoan
        {
            get
            {
                return TaiKhoan;
            }
            set
            {
                TaiKhoan = value;
            }
        }
        public string matkhau
        {
            get
            {
                return MatKhau;
            }
            set { 
                MatKhau = value;
            }
        }
        public int fk_maquyen
        {
            get
            {
                return FK_MaQuyen;
            }
            set
            {
                FK_MaQuyen = value;
            }
        }
        public TaiKhoan_DTO()
        {
            matk = "";
            taikhoan = "";
            matkhau = "";
            fk_maquyen = 1;
        }
        public TaiKhoan_DTO(string matk, string taikhoan, string matkhau, int fk_maquyen)
        {
            this.matk = matk;
            this.taikhoan = taikhoan;
            this.matkhau = matkhau;
            this.fk_maquyen=fk_maquyen;

        }
    }
}
