﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ThucDon_DTO
    {
         public string MaMA;

         public string TenMA;
         public int Calo;
         public int DonGia;
         public string FK_MaDD;
         public string FK_MaDM;

         public string mama
         {
             get
             {
                 return MaMA;
             }
             set { 
                 MaMA = value; 
             }
         }
         public string tenma
         {
             get
             {
                 return TenMA;
             }
             set
             {
                 TenMA = value;
             }
         }
         public int calo
         {
             get
             {
                 return Calo;
             }
             set
             {
                 Calo = value;
             }
         }
         public int dongia
         {
             get
             {
                 return DonGia;
             }
             set
             {
                 DonGia = value;
             }
         }
         public string madd
         {
             get
             {

                 return FK_MaDD;
             }
             set
             {
                 FK_MaDD = value;
             }   
         }
         public string madm
         {
             get
             {
                     return FK_MaDM;
             }
             set
             {
                 FK_MaDM = value;
             }
         }
        /*
        public string MaMA { get; set; }


        public string TenMA { get; set; }
        public int Calo { get; set; }
        public int DonGia { get; set; }
        public string FK_MaDD { get; set; }
        public string FK_MaDM { get; set; }
        */
        public ThucDon_DTO(string mama, string tenma, int calo, int dongia, string madd, string madm)
        {
            this.MaMA = mama;
            this.TenMA = tenma;
            this.Calo = calo;
            this.DonGia = dongia;
            this.FK_MaDD = madd;
            this.FK_MaDM = madm;
           /* this.mama = mama;
            this.tenma = tenma; 
            this.calo = calo;   
            this.dongia = dongia;
            this.fk_MaDD = fk_MaDD;
            this.fk_MaDM= fk_MaDM;
           */
        }
        
        public ThucDon_DTO() {
            this.MaMA = "";
            this.TenMA = "";
            this.Calo= 0;
            this.DonGia = 0;
            this.FK_MaDD = "";
            this.FK_MaDM = "";
        }
    }
}
