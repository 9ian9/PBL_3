﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ChiTietHD_DTO
    {
        public string MaHD { get; set; }
        public string TenMA { get; set; }
        public int SoLuong { get; set; }
        public int DonGia { get; set; }
        public int ThanhTien { get; set; }
        public ChiTietHD_DTO()
        {
            this.MaHD = "";
            this.TenMA = "";
            this.SoLuong = 0;   
            this.DonGia = 0;
            this.ThanhTien = 0;
        }
        public ChiTietHD_DTO(string mahd,string tenma, int soluong, int dongia , int thanhtien)
        {
            this.MaHD= mahd;
            this.TenMA= tenma;
            this.SoLuong = soluong;
            this.DonGia= dongia;
            this.ThanhTien= thanhtien;

        }

    }
}
