﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class HoaDon_DTO
    {
        public string MaHD { get; set; }
        public string MaNV { get; set; }
        public DateTime NgayBan { get; set; }
       public int TongTien { get; set; }
     //   public int TongTien { get; set; }
        public HoaDon_DTO()
        {
            this.MaHD = "";
            this.MaNV = "";
            this.NgayBan = new DateTime();
            this.TongTien = 0;
        }
        public HoaDon_DTO( string mahd, string manv, int tongtien)
        {
            this.MaHD = mahd;
            this.MaNV = manv;
            
           this.TongTien= tongtien;
        }
       
        
    }
}
