﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class QL_NhanVien : UserControl
    {
        NhanVien_BLL nhanvienbll = new NhanVien_BLL();
        TaiKhoan_BLL taikhoanbll  =new TaiKhoan_BLL();
        public QL_NhanVien()
        {
            InitializeComponent();
        }
     
        private void dgvNV_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            int numrows;
            numrows = e.RowIndex;
            txtMaNV.Text = dgvNV.Rows[numrows].Cells[0].Value.ToString();
            txtTenNV.Text = dgvNV.Rows[numrows].Cells[1].Value.ToString();
            txtGT.Text = dgvNV.Rows[numrows].Cells[2].Value.ToString();
            txtDC.Text = dgvNV.Rows[numrows].Cells[3].Value.ToString();
            txtSDT.Text = dgvNV.Rows[numrows].Cells[4].Value.ToString();
            cbMaTK.Text = dgvNV.Rows[numrows].Cells[5].Value.ToString();


        }

        private void dgvNV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void QL_NhanVien_Load_1(object sender, EventArgs e)
        {

            cbMaTK.DataSource = taikhoanbll.getMaTK();
            cbMaTK.DisplayMember = "MaTK";
            dgvNV.DataSource = nhanvienbll.getNV();
        }

        private void btThemnv_Click(object sender, EventArgs e)
        {

        }

        private void btSuaNV_Click(object sender, EventArgs e)
        {
            


        }

        private void btXoaNV_Click(object sender, EventArgs e)
        {
            DialogResult q = MessageBox.Show("Bạn Có Muốn Xóa nhân viên này Không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (q.Equals(DialogResult.Yes))
            {
               nhanvienbll.XoaNV(txtMaNV.Text, txtTenNV.Text, txtGT.Text, txtDC.Text, txtSDT.Text, cbMaTK.Text);
                QL_NhanVien_Load_1(sender, e);
            }
        }

        private void btThemNV_Click_1(object sender, EventArgs e)
        {

            if (txtMaNV.Text != "" && txtTenNV.Text != "" && txtGT.Text != "" && txtDC.Text != "" && txtSDT.Text != "" && cbMaTK.Text != "")
            {
                nhanvienbll.ThemNV(txtMaNV.Text, txtTenNV.Text, txtGT.Text, txtDC.Text, txtSDT.Text, cbMaTK.Text);
                MessageBox.Show("Add completed!");
                QL_NhanVien_Load_1(sender, e);


            }
            else
            {
                MessageBox.Show("Thêm Thất Bại,Bạn Phải Nhập Đầy Đủ Thông Tin", "Cảnh Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            txtMaNV.Text = "";
            txtTenNV.Text = "";
            txtGT.Text = "";
            txtDC.Text = "";
            txtSDT.Text = "";
            cbMaTK.Text = "";
        }

        private void btSuaNV_Click_1(object sender, EventArgs e)
        {
            if (dgvNV.SelectedRows.Count > 0)
            {
                if (txtMaNV.Text != "" && txtTenNV.Text != "" && txtGT.Text != "" && txtDC.Text != "" && txtSDT.Text != "" && cbMaTK.Text != "")
                {
                    NhanVien_DTO nhanvien = new NhanVien_DTO(txtMaNV.Text, txtTenNV.Text, txtGT.Text, txtDC.Text, txtSDT.Text, cbMaTK.Text);
                    if (nhanvienbll.editNV(nhanvien))
                    {
                        MessageBox.Show("Edit Completed!!");
                        dgvNV.DataSource = nhanvienbll.getNV();
                    }
                    else
                    {
                        MessageBox.Show("Edit failed");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter in full");
                }

            }
        }

        private void cbMaTK_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
