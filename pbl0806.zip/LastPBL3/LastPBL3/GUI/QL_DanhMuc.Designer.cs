﻿namespace GUI
{
    partial class QL_DanhMuc
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvDM = new System.Windows.Forms.DataGridView();
            this.MaDM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenDM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSuaDM = new Guna.UI.WinForms.GunaButton();
            this.btnXoaDM = new Guna.UI.WinForms.GunaButton();
            this.btnThemDM = new Guna.UI.WinForms.GunaButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtTenDM = new System.Windows.Forms.TextBox();
            this.txtMaDM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvDD = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnSuaDD = new Guna.UI.WinForms.GunaButton();
            this.btnXoaDD = new Guna.UI.WinForms.GunaButton();
            this.btnThemDD = new Guna.UI.WinForms.GunaButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtTenDD = new System.Windows.Forms.TextBox();
            this.txtMaDD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDM)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDD)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvDM);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(14, 29);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(652, 694);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // dgvDM
            // 
            this.dgvDM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaDM,
            this.TenDM});
            this.dgvDM.Location = new System.Drawing.Point(71, 299);
            this.dgvDM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvDM.Name = "dgvDM";
            this.dgvDM.RowHeadersWidth = 51;
            this.dgvDM.RowTemplate.Height = 24;
            this.dgvDM.Size = new System.Drawing.Size(474, 232);
            this.dgvDM.TabIndex = 12;
            this.dgvDM.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDM_CellClick);
            this.dgvDM.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDM_CellContentClick);
            // 
            // MaDM
            // 
            this.MaDM.DataPropertyName = "MaDM";
            this.MaDM.HeaderText = "Mã danh mục";
            this.MaDM.MinimumWidth = 6;
            this.MaDM.Name = "MaDM";
            // 
            // TenDM
            // 
            this.TenDM.DataPropertyName = "TenDM";
            this.TenDM.HeaderText = "Tên danh mục";
            this.TenDM.MinimumWidth = 6;
            this.TenDM.Name = "TenDM";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSuaDM);
            this.groupBox2.Controls.Add(this.btnXoaDM);
            this.groupBox2.Controls.Add(this.btnThemDM);
            this.groupBox2.Location = new System.Drawing.Point(94, 561);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(450, 96);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // btnSuaDM
            // 
            this.btnSuaDM.AnimationHoverSpeed = 0.07F;
            this.btnSuaDM.AnimationSpeed = 0.03F;
            this.btnSuaDM.BaseColor = System.Drawing.Color.White;
            this.btnSuaDM.BorderColor = System.Drawing.Color.Black;
            this.btnSuaDM.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSuaDM.FocusedColor = System.Drawing.Color.Empty;
            this.btnSuaDM.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaDM.ForeColor = System.Drawing.Color.Black;
            this.btnSuaDM.Image = global::GUI.Properties.Resources.Modify;
            this.btnSuaDM.ImageSize = new System.Drawing.Size(20, 20);
            this.btnSuaDM.Location = new System.Drawing.Point(296, 26);
            this.btnSuaDM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSuaDM.Name = "btnSuaDM";
            this.btnSuaDM.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnSuaDM.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnSuaDM.OnHoverForeColor = System.Drawing.Color.White;
            this.btnSuaDM.OnHoverImage = null;
            this.btnSuaDM.OnPressedColor = System.Drawing.Color.Black;
            this.btnSuaDM.Size = new System.Drawing.Size(105, 46);
            this.btnSuaDM.TabIndex = 2;
            this.btnSuaDM.Text = "Sửa";
            this.btnSuaDM.Click += new System.EventHandler(this.btnSuaDM_Click);
            // 
            // btnXoaDM
            // 
            this.btnXoaDM.AnimationHoverSpeed = 0.07F;
            this.btnXoaDM.AnimationSpeed = 0.03F;
            this.btnXoaDM.BaseColor = System.Drawing.Color.White;
            this.btnXoaDM.BorderColor = System.Drawing.Color.Black;
            this.btnXoaDM.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnXoaDM.FocusedColor = System.Drawing.Color.Empty;
            this.btnXoaDM.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaDM.ForeColor = System.Drawing.Color.Black;
            this.btnXoaDM.Image = global::GUI.Properties.Resources.Erase;
            this.btnXoaDM.ImageSize = new System.Drawing.Size(20, 20);
            this.btnXoaDM.Location = new System.Drawing.Point(156, 26);
            this.btnXoaDM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnXoaDM.Name = "btnXoaDM";
            this.btnXoaDM.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnXoaDM.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnXoaDM.OnHoverForeColor = System.Drawing.Color.White;
            this.btnXoaDM.OnHoverImage = null;
            this.btnXoaDM.OnPressedColor = System.Drawing.Color.Black;
            this.btnXoaDM.Size = new System.Drawing.Size(105, 46);
            this.btnXoaDM.TabIndex = 1;
            this.btnXoaDM.Text = "Xóa";
            this.btnXoaDM.Click += new System.EventHandler(this.btnXoaDM_Click);
            // 
            // btnThemDM
            // 
            this.btnThemDM.AnimationHoverSpeed = 0.07F;
            this.btnThemDM.AnimationSpeed = 0.03F;
            this.btnThemDM.BaseColor = System.Drawing.Color.White;
            this.btnThemDM.BorderColor = System.Drawing.Color.Black;
            this.btnThemDM.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnThemDM.FocusedColor = System.Drawing.Color.Empty;
            this.btnThemDM.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemDM.ForeColor = System.Drawing.Color.Black;
            this.btnThemDM.Image = global::GUI.Properties.Resources.Create;
            this.btnThemDM.ImageSize = new System.Drawing.Size(20, 20);
            this.btnThemDM.Location = new System.Drawing.Point(21, 26);
            this.btnThemDM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnThemDM.Name = "btnThemDM";
            this.btnThemDM.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnThemDM.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnThemDM.OnHoverForeColor = System.Drawing.Color.White;
            this.btnThemDM.OnHoverImage = null;
            this.btnThemDM.OnPressedColor = System.Drawing.Color.Black;
            this.btnThemDM.Size = new System.Drawing.Size(105, 46);
            this.btnThemDM.TabIndex = 0;
            this.btnThemDM.Text = "Thêm";
            this.btnThemDM.Click += new System.EventHandler(this.btnThemDM_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtTenDM);
            this.groupBox3.Controls.Add(this.txtMaDM);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(7, 112);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(594, 166);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            // 
            // txtTenDM
            // 
            this.txtTenDM.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDM.Location = new System.Drawing.Point(225, 86);
            this.txtTenDM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTenDM.Name = "txtTenDM";
            this.txtTenDM.Size = new System.Drawing.Size(332, 39);
            this.txtTenDM.TabIndex = 3;
            // 
            // txtMaDM
            // 
            this.txtMaDM.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDM.Location = new System.Drawing.Point(225, 28);
            this.txtMaDM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaDM.Name = "txtMaDM";
            this.txtMaDM.Size = new System.Drawing.Size(332, 39);
            this.txtMaDM.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "Tên Danh Mục";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã Danh Mục";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(224, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 45);
            this.label1.TabIndex = 9;
            this.label1.Text = "DANH MỤC";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgvDD);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(684, 29);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(652, 694);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // dgvDD
            // 
            this.dgvDD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgvDD.Location = new System.Drawing.Point(71, 299);
            this.dgvDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvDD.Name = "dgvDD";
            this.dgvDD.RowHeadersWidth = 51;
            this.dgvDD.RowTemplate.Height = 24;
            this.dgvDD.Size = new System.Drawing.Size(474, 232);
            this.dgvDD.TabIndex = 12;
            this.dgvDD.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDD_CellClick);
            this.dgvDD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDD_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MaDD";
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã dinh dưỡng";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TenDD";
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên dinh dưỡng";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnSuaDD);
            this.groupBox5.Controls.Add(this.btnXoaDD);
            this.groupBox5.Controls.Add(this.btnThemDD);
            this.groupBox5.Location = new System.Drawing.Point(94, 561);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(450, 96);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            // 
            // btnSuaDD
            // 
            this.btnSuaDD.AnimationHoverSpeed = 0.07F;
            this.btnSuaDD.AnimationSpeed = 0.03F;
            this.btnSuaDD.BaseColor = System.Drawing.Color.White;
            this.btnSuaDD.BorderColor = System.Drawing.Color.Black;
            this.btnSuaDD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSuaDD.FocusedColor = System.Drawing.Color.Empty;
            this.btnSuaDD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaDD.ForeColor = System.Drawing.Color.Black;
            this.btnSuaDD.Image = global::GUI.Properties.Resources.Modify;
            this.btnSuaDD.ImageSize = new System.Drawing.Size(20, 20);
            this.btnSuaDD.Location = new System.Drawing.Point(296, 26);
            this.btnSuaDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSuaDD.Name = "btnSuaDD";
            this.btnSuaDD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnSuaDD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnSuaDD.OnHoverForeColor = System.Drawing.Color.White;
            this.btnSuaDD.OnHoverImage = null;
            this.btnSuaDD.OnPressedColor = System.Drawing.Color.Black;
            this.btnSuaDD.Size = new System.Drawing.Size(105, 46);
            this.btnSuaDD.TabIndex = 2;
            this.btnSuaDD.Text = "Sửa";
            this.btnSuaDD.Click += new System.EventHandler(this.btnSuaDD_Click);
            // 
            // btnXoaDD
            // 
            this.btnXoaDD.AnimationHoverSpeed = 0.07F;
            this.btnXoaDD.AnimationSpeed = 0.03F;
            this.btnXoaDD.BaseColor = System.Drawing.Color.White;
            this.btnXoaDD.BorderColor = System.Drawing.Color.Black;
            this.btnXoaDD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnXoaDD.FocusedColor = System.Drawing.Color.Empty;
            this.btnXoaDD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaDD.ForeColor = System.Drawing.Color.Black;
            this.btnXoaDD.Image = global::GUI.Properties.Resources.Erase;
            this.btnXoaDD.ImageSize = new System.Drawing.Size(20, 20);
            this.btnXoaDD.Location = new System.Drawing.Point(156, 26);
            this.btnXoaDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnXoaDD.Name = "btnXoaDD";
            this.btnXoaDD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnXoaDD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnXoaDD.OnHoverForeColor = System.Drawing.Color.White;
            this.btnXoaDD.OnHoverImage = null;
            this.btnXoaDD.OnPressedColor = System.Drawing.Color.Black;
            this.btnXoaDD.Size = new System.Drawing.Size(105, 46);
            this.btnXoaDD.TabIndex = 1;
            this.btnXoaDD.Text = "Xóa";
            this.btnXoaDD.Click += new System.EventHandler(this.btnXoaDD_Click);
            // 
            // btnThemDD
            // 
            this.btnThemDD.AnimationHoverSpeed = 0.07F;
            this.btnThemDD.AnimationSpeed = 0.03F;
            this.btnThemDD.BaseColor = System.Drawing.Color.White;
            this.btnThemDD.BorderColor = System.Drawing.Color.Black;
            this.btnThemDD.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnThemDD.FocusedColor = System.Drawing.Color.Empty;
            this.btnThemDD.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemDD.ForeColor = System.Drawing.Color.Black;
            this.btnThemDD.Image = global::GUI.Properties.Resources.Create;
            this.btnThemDD.ImageSize = new System.Drawing.Size(20, 20);
            this.btnThemDD.Location = new System.Drawing.Point(21, 26);
            this.btnThemDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnThemDD.Name = "btnThemDD";
            this.btnThemDD.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnThemDD.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnThemDD.OnHoverForeColor = System.Drawing.Color.White;
            this.btnThemDD.OnHoverImage = null;
            this.btnThemDD.OnPressedColor = System.Drawing.Color.Black;
            this.btnThemDD.Size = new System.Drawing.Size(105, 46);
            this.btnThemDD.TabIndex = 0;
            this.btnThemDD.Text = "Thêm";
            this.btnThemDD.Click += new System.EventHandler(this.btnThemDD_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtTenDD);
            this.groupBox6.Controls.Add(this.txtMaDD);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Location = new System.Drawing.Point(7, 112);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Size = new System.Drawing.Size(594, 166);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            // 
            // txtTenDD
            // 
            this.txtTenDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDD.Location = new System.Drawing.Point(240, 86);
            this.txtTenDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTenDD.Name = "txtTenDD";
            this.txtTenDD.Size = new System.Drawing.Size(332, 39);
            this.txtTenDD.TabIndex = 3;
            // 
            // txtMaDD
            // 
            this.txtMaDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDD.Location = new System.Drawing.Point(240, 27);
            this.txtMaDD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaDD.Name = "txtMaDD";
            this.txtMaDD.Size = new System.Drawing.Size(332, 39);
            this.txtMaDD.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(201, 32);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tên Dinh Dưỡng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(197, 32);
            this.label5.TabIndex = 0;
            this.label5.Text = "Mã Dinh Dưỡng";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(224, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(239, 45);
            this.label6.TabIndex = 9;
            this.label6.Text = "DINH DƯỠNG";
            // 
            // QL_DanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "QL_DanhMuc";
            this.Size = new System.Drawing.Size(1418, 749);
            this.Load += new System.EventHandler(this.QL_DanhMuc_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDM)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDD)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvDM;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaDM;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenDM;
        private System.Windows.Forms.GroupBox groupBox2;
        private Guna.UI.WinForms.GunaButton btnSuaDM;
        private Guna.UI.WinForms.GunaButton btnXoaDM;
        private Guna.UI.WinForms.GunaButton btnThemDM;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtTenDM;
        private System.Windows.Forms.TextBox txtMaDM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgvDD;
        private System.Windows.Forms.GroupBox groupBox5;
        private Guna.UI.WinForms.GunaButton btnSuaDD;
        private Guna.UI.WinForms.GunaButton btnXoaDD;
        private Guna.UI.WinForms.GunaButton btnThemDD;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtTenDD;
        private System.Windows.Forms.TextBox txtMaDD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}
