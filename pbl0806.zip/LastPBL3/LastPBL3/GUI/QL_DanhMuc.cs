﻿using BLL;
using DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class QL_DanhMuc : UserControl
    {
        DanhMuc_BLL danhmucbll = new DanhMuc_BLL();
        DinhDuong_BLL dinhduongbll = new DinhDuong_BLL();
        public QL_DanhMuc()
        {
            InitializeComponent();
        }

        private void QL_DanhMuc_Load(object sender, EventArgs e)
        {
            dgvDM.DataSource = danhmucbll.getDM();
            dgvDD.DataSource = dinhduongbll.getDD();

        }

        private void dgvDanhMuc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void dgvDM_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvDM_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrow;
            numrow = e.RowIndex;
            txtMaDM.Text = dgvDM.Rows[numrow].Cells[0].Value.ToString();
            txtTenDM.Text = dgvDM.Rows[numrow].Cells[1].Value.ToString();
        }

        private void dgvDD_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvDD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int numrows;
            numrows = e.RowIndex;
            txtMaDD.Text = dgvDD.Rows[numrows].Cells[0].Value.ToString();
            txtTenDD.Text = dgvDD.Rows[numrows].Cells[1].Value.ToString();
        }

        private void btnThemDM_Click(object sender, EventArgs e)
        {
            if (txtMaDM.Text != "" && txtTenDM.Text != "") 
            {
                danhmucbll.ThemDM(txtMaDM.Text, txtTenDM.Text);
             
                MessageBox.Show("Add completed!");
                QL_DanhMuc_Load(sender, e);
               

            }
            else
            {
                MessageBox.Show("Thêm Thất Bại,Bạn Phải Nhập Đầy Đủ Thông Tin", "Cảnh Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

        }

        private void btnXoaDM_Click(object sender, EventArgs e)
        {

            DialogResult q = MessageBox.Show("Bạn Có Muốn Xóa Danh mục này không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (q.Equals(DialogResult.Yes))
            {
                danhmucbll.XoaDM(txtMaDM.Text, txtTenDM.Text);
                QL_DanhMuc_Load(sender, e);

            }
        }

        private void btnSuaDM_Click(object sender, EventArgs e)
        {
            if (dgvDM.SelectedRows.Count > 0)
            {
                if (txtMaDM.Text != "" && txtTenDM.Text != "" )
                {
                  
                    DanhMuc_DTO danhMuc = new DanhMuc_DTO(txtMaDM.Text, txtTenDM.Text);

                    if (danhmucbll.editDM(danhMuc))
                    {
                        MessageBox.Show("Edit Completed!!");
                        dgvDM.DataSource = danhmucbll.getDM();

                    }
                    else
                    {
                        MessageBox.Show("Edit failed");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter in full");
                }
            }
        }

        private void btnThemDD_Click(object sender, EventArgs e)
        {
            if (txtMaDD.Text != "" && txtTenDD.Text != "")
            {
                dinhduongbll.ThemDD(txtMaDD.Text, txtTenDD.Text);

                MessageBox.Show("Add completed!");
                QL_DanhMuc_Load(sender, e);


            }
            else
            {
                MessageBox.Show("Thêm Thất Bại,Bạn Phải Nhập Đầy Đủ Thông Tin", "Cảnh Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void btnXoaDD_Click(object sender, EventArgs e)
        {

            DialogResult q = MessageBox.Show("Bạn Có Muốn Xóa Dinh dưỡng này không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (q.Equals(DialogResult.Yes))
            {
                dinhduongbll.XoaDD(txtMaDD.Text, txtTenDD.Text);
                QL_DanhMuc_Load(sender, e);

            }
        }

        private void btnSuaDD_Click(object sender, EventArgs e)
        {
            if (dgvDD.SelectedRows.Count > 0)
            {
                if (txtMaDD.Text != "" && txtTenDD.Text != "")
                {

                    DinhDuong_DTO dinhduong = new DinhDuong_DTO(txtMaDD.Text, txtTenDD.Text);

                    if (dinhduongbll.editDD(dinhduong))
                    {
                        MessageBox.Show("Edit Completed!!");
                        dgvDD.DataSource = dinhduongbll.getDD();

                    }
                    else
                    {
                        MessageBox.Show("Edit failed");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter in full");
                }
            }
        }
    }
}
