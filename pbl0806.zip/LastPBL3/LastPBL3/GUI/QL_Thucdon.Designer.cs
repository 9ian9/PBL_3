﻿namespace GUI
{
    partial class QL_Thucdon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbDM = new System.Windows.Forms.ComboBox();
            this.tblMonAnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pBL3DataSet2 = new GUI.PBL3DataSet2();
            this.cbDD = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btXemMA = new Guna.UI.WinForms.GunaButton();
            this.btTimMA = new Guna.UI.WinForms.GunaButton();
            this.txtTimMA = new System.Windows.Forms.TextBox();
            this.btResetMA = new Guna.UI.WinForms.GunaButton();
            this.btSuaMA = new Guna.UI.WinForms.GunaButton();
            this.btThemMA = new Guna.UI.WinForms.GunaButton();
            this.btXoaMA = new Guna.UI.WinForms.GunaButton();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCalo = new System.Windows.Forms.TextBox();
            this.txtTenMA = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaMA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvMA = new System.Windows.Forms.DataGridView();
            this.pBL3DataSet1 = new GUI.PBL3DataSet1();
            this.tblMonAnTableAdapter = new GUI.PBL3DataSet2TableAdapters.tblMonAnTableAdapter();
            this.pBL3DataSet3 = new GUI.PBL3DataSet3();
            this.tblDinhDuongBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblDinhDuongTableAdapter = new GUI.PBL3DataSet3TableAdapters.tblDinhDuongTableAdapter();
            this.pBL3DataSet4 = new GUI.PBL3DataSet4();
            this.tblDanhMucBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblDanhMucTableAdapter = new GUI.PBL3DataSet4TableAdapters.tblDanhMucTableAdapter();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblMonAnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDinhDuongBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDanhMucBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.cbDM);
            this.groupBox1.Controls.Add(this.cbDD);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.txtDonGia);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCalo);
            this.groupBox1.Controls.Add(this.txtTenMA);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMaMA);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(18, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(536, 439);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // cbDM
            // 
            this.cbDM.DataSource = this.tblMonAnBindingSource;
            this.cbDM.DisplayMember = "FK_MaDM";
            this.cbDM.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDM.FormattingEnabled = true;
            this.cbDM.Location = new System.Drawing.Point(192, 250);
            this.cbDM.Name = "cbDM";
            this.cbDM.Size = new System.Drawing.Size(292, 31);
            this.cbDM.TabIndex = 11;
            this.cbDM.ValueMember = "FK_MaDM";
            this.cbDM.SelectedIndexChanged += new System.EventHandler(this.cbDM_SelectedIndexChanged);
            // 
            // tblMonAnBindingSource
            // 
            this.tblMonAnBindingSource.DataMember = "tblMonAn";
            this.tblMonAnBindingSource.DataSource = this.pBL3DataSet2;
            // 
            // pBL3DataSet2
            // 
            this.pBL3DataSet2.DataSetName = "PBL3DataSet2";
            this.pBL3DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cbDD
            // 
            this.cbDD.DataSource = this.tblMonAnBindingSource;
            this.cbDD.DisplayMember = "FK_MaDD";
            this.cbDD.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDD.FormattingEnabled = true;
            this.cbDD.Location = new System.Drawing.Point(192, 208);
            this.cbDD.Name = "cbDD";
            this.cbDD.Size = new System.Drawing.Size(292, 31);
            this.cbDD.TabIndex = 10;
            this.cbDD.ValueMember = "FK_MaDD";
            this.cbDD.SelectedIndexChanged += new System.EventHandler(this.cbDD_SelectedIndexChanged);
            this.cbDD.DataSourceChanged += new System.EventHandler(this.cbDD_DataSourceChanged);
            this.cbDD.ValueMemberChanged += new System.EventHandler(this.cbDD_ValueMemberChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btXemMA);
            this.panel1.Controls.Add(this.btTimMA);
            this.panel1.Controls.Add(this.txtTimMA);
            this.panel1.Controls.Add(this.btResetMA);
            this.panel1.Controls.Add(this.btSuaMA);
            this.panel1.Controls.Add(this.btThemMA);
            this.panel1.Controls.Add(this.btXoaMA);
            this.panel1.Location = new System.Drawing.Point(6, 303);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 119);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btXemMA
            // 
            this.btXemMA.AnimationHoverSpeed = 0.07F;
            this.btXemMA.AnimationSpeed = 0.03F;
            this.btXemMA.BaseColor = System.Drawing.Color.White;
            this.btXemMA.BorderColor = System.Drawing.Color.Black;
            this.btXemMA.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btXemMA.FocusedColor = System.Drawing.Color.Empty;
            this.btXemMA.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXemMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btXemMA.Image = global::GUI.Properties.Resources.Eye;
            this.btXemMA.ImageSize = new System.Drawing.Size(20, 20);
            this.btXemMA.Location = new System.Drawing.Point(429, 13);
            this.btXemMA.Name = "btXemMA";
            this.btXemMA.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btXemMA.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btXemMA.OnHoverForeColor = System.Drawing.Color.White;
            this.btXemMA.OnHoverImage = null;
            this.btXemMA.OnPressedColor = System.Drawing.Color.Black;
            this.btXemMA.Size = new System.Drawing.Size(91, 34);
            this.btXemMA.TabIndex = 14;
            this.btXemMA.Text = "Xem";
            this.btXemMA.Click += new System.EventHandler(this.btXemMA_Click);
            // 
            // btTimMA
            // 
            this.btTimMA.AnimationHoverSpeed = 0.07F;
            this.btTimMA.AnimationSpeed = 0.03F;
            this.btTimMA.BaseColor = System.Drawing.Color.White;
            this.btTimMA.BorderColor = System.Drawing.Color.Black;
            this.btTimMA.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btTimMA.FocusedColor = System.Drawing.Color.Empty;
            this.btTimMA.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTimMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btTimMA.Image = global::GUI.Properties.Resources.View;
            this.btTimMA.ImageSize = new System.Drawing.Size(20, 20);
            this.btTimMA.Location = new System.Drawing.Point(361, 70);
            this.btTimMA.Name = "btTimMA";
            this.btTimMA.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btTimMA.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btTimMA.OnHoverForeColor = System.Drawing.Color.White;
            this.btTimMA.OnHoverImage = null;
            this.btTimMA.OnPressedColor = System.Drawing.Color.Black;
            this.btTimMA.Size = new System.Drawing.Size(124, 34);
            this.btTimMA.TabIndex = 13;
            this.btTimMA.Text = "Tìm kiếm";
            this.btTimMA.Click += new System.EventHandler(this.btTimMA_Click);
            // 
            // txtTimMA
            // 
            this.txtTimMA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimMA.Location = new System.Drawing.Point(40, 70);
            this.txtTimMA.Name = "txtTimMA";
            this.txtTimMA.Size = new System.Drawing.Size(292, 30);
            this.txtTimMA.TabIndex = 12;
            // 
            // btResetMA
            // 
            this.btResetMA.AnimationHoverSpeed = 0.07F;
            this.btResetMA.AnimationSpeed = 0.03F;
            this.btResetMA.BaseColor = System.Drawing.Color.White;
            this.btResetMA.BorderColor = System.Drawing.Color.Black;
            this.btResetMA.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btResetMA.FocusedColor = System.Drawing.Color.Empty;
            this.btResetMA.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btResetMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btResetMA.Image = global::GUI.Properties.Resources.Redo;
            this.btResetMA.ImageSize = new System.Drawing.Size(20, 20);
            this.btResetMA.Location = new System.Drawing.Point(330, 13);
            this.btResetMA.Name = "btResetMA";
            this.btResetMA.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btResetMA.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btResetMA.OnHoverForeColor = System.Drawing.Color.White;
            this.btResetMA.OnHoverImage = null;
            this.btResetMA.OnPressedColor = System.Drawing.Color.Black;
            this.btResetMA.Size = new System.Drawing.Size(89, 34);
            this.btResetMA.TabIndex = 3;
            this.btResetMA.Text = "Reset";
            this.btResetMA.Click += new System.EventHandler(this.btResetMA_Click_1);
            // 
            // btSuaMA
            // 
            this.btSuaMA.AnimationHoverSpeed = 0.07F;
            this.btSuaMA.AnimationSpeed = 0.03F;
            this.btSuaMA.BaseColor = System.Drawing.Color.White;
            this.btSuaMA.BorderColor = System.Drawing.Color.Black;
            this.btSuaMA.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btSuaMA.FocusedColor = System.Drawing.Color.Empty;
            this.btSuaMA.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSuaMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btSuaMA.Image = global::GUI.Properties.Resources.Modify;
            this.btSuaMA.ImageSize = new System.Drawing.Size(20, 20);
            this.btSuaMA.Location = new System.Drawing.Point(116, 13);
            this.btSuaMA.Name = "btSuaMA";
            this.btSuaMA.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btSuaMA.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btSuaMA.OnHoverForeColor = System.Drawing.Color.White;
            this.btSuaMA.OnHoverImage = null;
            this.btSuaMA.OnPressedColor = System.Drawing.Color.Black;
            this.btSuaMA.Size = new System.Drawing.Size(90, 34);
            this.btSuaMA.TabIndex = 2;
            this.btSuaMA.Text = "Sửa";
            this.btSuaMA.Click += new System.EventHandler(this.btSuaMA_Click);
            // 
            // btThemMA
            // 
            this.btThemMA.AnimationHoverSpeed = 0.07F;
            this.btThemMA.AnimationSpeed = 0.03F;
            this.btThemMA.BaseColor = System.Drawing.Color.White;
            this.btThemMA.BorderColor = System.Drawing.Color.Black;
            this.btThemMA.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btThemMA.FocusedColor = System.Drawing.Color.Empty;
            this.btThemMA.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThemMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btThemMA.Image = global::GUI.Properties.Resources.Create;
            this.btThemMA.ImageSize = new System.Drawing.Size(20, 20);
            this.btThemMA.Location = new System.Drawing.Point(3, 13);
            this.btThemMA.Name = "btThemMA";
            this.btThemMA.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btThemMA.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btThemMA.OnHoverForeColor = System.Drawing.Color.White;
            this.btThemMA.OnHoverImage = null;
            this.btThemMA.OnPressedColor = System.Drawing.Color.Black;
            this.btThemMA.Size = new System.Drawing.Size(94, 34);
            this.btThemMA.TabIndex = 1;
            this.btThemMA.Text = "Thêm";
            this.btThemMA.Click += new System.EventHandler(this.btThemMA_Click);
            // 
            // btXoaMA
            // 
            this.btXoaMA.AnimationHoverSpeed = 0.07F;
            this.btXoaMA.AnimationSpeed = 0.03F;
            this.btXoaMA.BaseColor = System.Drawing.Color.White;
            this.btXoaMA.BorderColor = System.Drawing.Color.Black;
            this.btXoaMA.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btXoaMA.FocusedColor = System.Drawing.Color.Empty;
            this.btXoaMA.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoaMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btXoaMA.Image = global::GUI.Properties.Resources.Erase;
            this.btXoaMA.ImageSize = new System.Drawing.Size(20, 20);
            this.btXoaMA.Location = new System.Drawing.Point(224, 13);
            this.btXoaMA.Name = "btXoaMA";
            this.btXoaMA.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btXoaMA.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btXoaMA.OnHoverForeColor = System.Drawing.Color.White;
            this.btXoaMA.OnHoverImage = null;
            this.btXoaMA.OnPressedColor = System.Drawing.Color.Black;
            this.btXoaMA.Size = new System.Drawing.Size(89, 34);
            this.btXoaMA.TabIndex = 0;
            this.btXoaMA.Text = "Xóa";
            this.btXoaMA.Click += new System.EventHandler(this.btXoaMA_Click);
            // 
            // txtDonGia
            // 
            this.txtDonGia.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGia.Location = new System.Drawing.Point(192, 164);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(292, 30);
            this.txtDonGia.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(20, 252);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 23);
            this.label6.TabIndex = 8;
            this.label6.Text = "Danh Mục";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(20, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 23);
            this.label5.TabIndex = 7;
            this.label5.Text = "Loại Dinh Dưỡng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(20, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "Đơn giá";
            // 
            // txtCalo
            // 
            this.txtCalo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalo.Location = new System.Drawing.Point(192, 117);
            this.txtCalo.Name = "txtCalo";
            this.txtCalo.Size = new System.Drawing.Size(292, 30);
            this.txtCalo.TabIndex = 5;
            // 
            // txtTenMA
            // 
            this.txtTenMA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenMA.Location = new System.Drawing.Point(192, 71);
            this.txtTenMA.Name = "txtTenMA";
            this.txtTenMA.Size = new System.Drawing.Size(292, 30);
            this.txtTenMA.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(20, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tên Món Ăn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(20, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Calo";
            // 
            // txtMaMA
            // 
            this.txtMaMA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaMA.Location = new System.Drawing.Point(192, 28);
            this.txtMaMA.Name = "txtMaMA";
            this.txtMaMA.Size = new System.Drawing.Size(292, 30);
            this.txtMaMA.TabIndex = 1;
            this.txtMaMA.TextChanged += new System.EventHandler(this.txtMaMA_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(20, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Món Ăn";
            // 
            // dgvMA
            // 
            this.dgvMA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMA.ColumnHeadersHeight = 29;
            this.dgvMA.Location = new System.Drawing.Point(560, 32);
            this.dgvMA.Name = "dgvMA";
            this.dgvMA.RowHeadersWidth = 51;
            this.dgvMA.RowTemplate.Height = 24;
            this.dgvMA.Size = new System.Drawing.Size(684, 517);
            this.dgvMA.TabIndex = 1;
            this.dgvMA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMA_CellClick);
            this.dgvMA.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMA_CellContentClick_1);
            // 
            // pBL3DataSet1
            // 
            this.pBL3DataSet1.DataSetName = "PBL3DataSet1";
            this.pBL3DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblMonAnTableAdapter
            // 
            this.tblMonAnTableAdapter.ClearBeforeFill = true;
            // 
            // pBL3DataSet3
            // 
            this.pBL3DataSet3.DataSetName = "PBL3DataSet3";
            this.pBL3DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblDinhDuongBindingSource
            // 
            this.tblDinhDuongBindingSource.DataMember = "tblDinhDuong";
            this.tblDinhDuongBindingSource.DataSource = this.pBL3DataSet3;
            // 
            // tblDinhDuongTableAdapter
            // 
            this.tblDinhDuongTableAdapter.ClearBeforeFill = true;
            // 
            // pBL3DataSet4
            // 
            this.pBL3DataSet4.DataSetName = "PBL3DataSet4";
            this.pBL3DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblDanhMucBindingSource
            // 
            this.tblDanhMucBindingSource.DataMember = "tblDanhMuc";
            this.tblDanhMucBindingSource.DataSource = this.pBL3DataSet4;
            // 
            // tblDanhMucTableAdapter
            // 
            this.tblDanhMucTableAdapter.ClearBeforeFill = true;
            // 
            // QL_Thucdon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.dgvMA);
            this.Controls.Add(this.groupBox1);
            this.Name = "QL_Thucdon";
            this.Size = new System.Drawing.Size(1271, 625);
            this.Load += new System.EventHandler(this.QL_Thucdon_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblMonAnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDinhDuongBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBL3DataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDanhMucBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCalo;
        private System.Windows.Forms.TextBox txtTenMA;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaMA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaButton btSuaMA;
        private Guna.UI.WinForms.GunaButton btThemMA;
        private Guna.UI.WinForms.GunaButton btXoaMA;
        private Guna.UI.WinForms.GunaButton btResetMA;
        private Guna.UI.WinForms.GunaButton btTimMA;
        private System.Windows.Forms.TextBox txtTimMA;
        private System.Windows.Forms.ComboBox cbDM;
        private System.Windows.Forms.ComboBox cbDD;
        private System.Windows.Forms.DataGridView dgvMA;
        private PBL3DataSet1 pBL3DataSet1;
        private System.Windows.Forms.BindingSource tblMonAnBindingSource;
        private PBL3DataSet2 pBL3DataSet2;
        private PBL3DataSet2TableAdapters.tblMonAnTableAdapter tblMonAnTableAdapter;
        private System.Windows.Forms.BindingSource tblDanhMucBindingSource;
        private PBL3DataSet4 pBL3DataSet4;
        private System.Windows.Forms.BindingSource tblDinhDuongBindingSource;
        private PBL3DataSet3 pBL3DataSet3;
        private PBL3DataSet3TableAdapters.tblDinhDuongTableAdapter tblDinhDuongTableAdapter;
        private PBL3DataSet4TableAdapters.tblDanhMucTableAdapter tblDanhMucTableAdapter;
        private Guna.UI.WinForms.GunaButton btXemMA;

        //   private PBL3DataSet2 pBL3DataSet2;
        //  private PBL3DataSet2TableAdapters.tblDanhMucTableAdapter tblDanhMucTableAdapter1;
    }
}
