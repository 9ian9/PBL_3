﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GUI;
using BLL;
namespace GUI
{
    public partial class frmMain : Form
    {
        public static string UsertName = "";
        public delegate void SendMessage(string Message);
        public SendMessage Sender;
        public frmMain()
        {
            InitializeComponent();
            Sender = new SendMessage(GetMessage);
        }
        private void GetMessage(string Message)
        {
            txtUser.Text = Message;
        }
        private void btThucDon_Click(object sender, EventArgs e)
        {
            panelControl.Controls.Clear();
            QL_Thucdon fthucdon = new QL_Thucdon();
            fthucdon.Dock = DockStyle.Fill;
            panelControl.Controls.Add(fthucdon);
        }
        private void btDangXuat_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Bạn có chắc chắn muốn đăng xuất không?", "Thông báo", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                // CloseSockets();
                this.Close();
                frmDangnhap dangnhap = new frmDangnhap();
                dangnhap.Show();
                
            }
            
        }
        private void btHoaDon_Click(object sender, EventArgs e)
        {
            panelControl.Controls.Clear();
            QL_Hoadon fhoadon = new QL_Hoadon();
            fhoadon.Dock = DockStyle.Fill;
            panelControl.Controls.Add(fhoadon);
        }

        private void btThongKe_Click(object sender, EventArgs e)
        {
            panelControl.Controls.Clear();
            QL_Thongke fthongke = new QL_Thongke(); 
            fthongke.Dock = DockStyle.Fill;
            panelControl.Controls.Add(fthongke);
        }

        private void btDanhMuc_Click(object sender, EventArgs e)
        {
            panelControl.Controls.Clear();
            QL_DanhMuc fdanhmuc = new QL_DanhMuc();
            fdanhmuc.Dock = DockStyle.Fill;
            panelControl.Controls.Add(fdanhmuc);
        }

        private void panelControl_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btTaiKhoan_Click(object sender, EventArgs e)
        {
            
        }

        private void btNhanVien_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "admin1")
            {
                panelControl.Controls.Clear();
                QL_NhanVien fnhanvien = new QL_NhanVien();
                fnhanvien.Dock = DockStyle.Fill;
                panelControl.Controls.Add (fnhanvien);

            }
            else
            {
                MessageBox.Show("Không có quyền truy cập!");
            }
        }
    }
}
