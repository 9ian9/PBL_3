﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;


namespace BLL
{
    public class ThucDon_BLL
    {
        ThucDon_DAL dalthucdon = new ThucDon_DAL();
        public DataTable getMA()
        {
            return dalthucdon.getMA(); ;
        }
        public void getcbMA()
        {
             dalthucdon.getcbMA(); 
        }
        
       
        public void themma(string mama, string tenma, int calo, int dongia, string madd, string madm)
        {
            //  dalthucdon.themMA(mama, tenma, calo, dongia, madd, madm);
            dalthucdon.themMA(new ThucDon_DTO(mama, tenma, calo, dongia, madd, madm));
        }
        public bool editMA(ThucDon_DTO thucDon)
        {
            return dalthucdon.editMA(thucDon);
        }
       
       
   
        public void XoaSP(string mama, string tenma, int calo, int dongia, string madd, string madm)
        {
            dalthucdon.Xoa(new ThucDon_DTO(mama, tenma, calo, dongia, madd, madm));
        }
        
        public string getMaMA(string tenma)
        {
            return dalthucdon.getMaMA(tenma);
        }
     
        
        public string getDonGia(string dongia)
        {
            return dalthucdon.getDonGia(dongia);
        }
        public string getTenMA(string tenma)
        {
            return dalthucdon.getTenMA(tenma);
        }
        
        public DataTable ListTK(string tma)
        {
            return dalthucdon.ListTK(tma);
        }
        public  int tongbanghi(string mama)
        {
            return dalthucdon.DemBanGhi(mama);
        }
       
    }
}
