﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;
namespace BLL
{
   public class HoaDon_BLL
    {
        HoaDon_DAL hoadondal = new HoaDon_DAL();

        
        public DataTable getHD()
        {
            return hoadondal.getHD();
        }
        public DataTable getMaNV()
        {
            return hoadondal.getMaNV();
        }
        public void Themhd(string mahd, string manv,int tongtien)
        {
            
            hoadondal.Them(new HoaDon_DTO(mahd, manv,tongtien));
        }
        public bool editHD(HoaDon_DTO hd)
        {
            return hoadondal.editHD(hd);
        }

        public void Xoahd(string mahd, string manv, int tongtien)
        {

            hoadondal.Xoa(new HoaDon_DTO(mahd, manv, tongtien));
        }
        public DataTable Listhd(string mahd)
        {
       
            return hoadondal.hd(mahd);
        }
        public int tongbanghi(string mahd)
        {
            return hoadondal.DemBanGhi(mahd);
           
        }
    }
}
