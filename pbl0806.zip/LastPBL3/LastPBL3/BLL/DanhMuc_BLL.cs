﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
namespace BLL
{
    public class DanhMuc_BLL
    {
        DanhMuc_DAL daldanhmuc = new DanhMuc_DAL();    
        public DataTable getDM()
        {
            return daldanhmuc.getDM();
        }
        public DataTable getMaDM()
        {
            return daldanhmuc.getMaDM();
        }
        public void ThemDM(string madm, string tendm)
        {
            daldanhmuc.ThemDM(new DanhMuc_DTO( madm, tendm));
        }
        public void XoaDM(string madm, string tendm)
        {
            daldanhmuc.XoaDM(new DanhMuc_DTO(madm, tendm));
        }
        public bool editDM(DanhMuc_DTO danhmuc)
        {
            return daldanhmuc.editDM(danhmuc);
        }
    }
}
