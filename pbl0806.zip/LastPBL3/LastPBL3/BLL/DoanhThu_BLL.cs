﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using static DAL.DBconnect;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class DoanhThu_BLL
    {
        public List<decimal> totalByDay = new List<decimal>();
        public List<string> ngayThang = new List<string>();
        SqlConnection conn = SqlConnectionData.Connect();
        
        public List<decimal> DoanhThu()
        {
            conn.Open();
            //string query = "SELECT NgayBan, SUM(TongTien) as tongtien_ngay FROM tblHoaDon GROUP BY NgayBan";
            string query = "SELECT FORMAT(NgayBan, 'dd/MM') as NgayThang, SUM(TongTien) as tongtien_ngay FROM tblHoaDon GROUP BY FORMAT(NgayBan, 'dd/MM')";
            SqlCommand command = new SqlCommand(query, conn);
            
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                decimal total = Convert.ToDecimal(reader["tongtien_ngay"]);
                string ngayThangValue = reader["NgayThang"].ToString();                
                ngayThang.Add(ngayThangValue);
                totalByDay.Add(total);
            }

            conn.Close();
            return totalByDay;
        }
    }
}
