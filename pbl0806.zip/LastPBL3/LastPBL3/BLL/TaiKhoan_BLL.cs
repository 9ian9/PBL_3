﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;
using System.Data;

namespace BLL
{
    public class TaiKhoan_BLL
    {
        TaiKhoan_DAL dalTaiKhoan = new TaiKhoan_DAL();
        public string CheckLogic(TaiKhoan_DTO taikhoan)
        {
            if (taikhoan.TaiKhoan == "")
            {
                return "requeid_taikhoan";
            }
            if (taikhoan.MatKhau == "")
            {
                return "requeid_password";

            }
            string info = dalTaiKhoan.CheckLogic(taikhoan);
            return info;
        }
        public DataTable getMaTK()
        {
            return dalTaiKhoan.getMaTK();
        }
    }
}
