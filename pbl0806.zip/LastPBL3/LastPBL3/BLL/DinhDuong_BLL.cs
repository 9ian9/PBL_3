﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class DinhDuong_BLL
    {
        DinhDuong_DAL daldinhduong = new DinhDuong_DAL();
        public DataTable getDD()
        {
            return daldinhduong.getDD();
        }
        public DataTable getMaDD()
        {
            return daldinhduong.getMaDD();
        }
        public void ThemDD(string madd, string tendd)
        {
            daldinhduong.ThemDD(new DinhDuong_DTO(madd, tendd));
        }
        public void XoaDD(string madd, string tendd)
        {
            daldinhduong.XoaDD(new DinhDuong_DTO(madd, tendd));
        }
        public bool editDD(DinhDuong_DTO dinhduong)
        {
            return daldinhduong.editDD(dinhduong);
        }
    }
}
