﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using static DAL.DBconnect;
using System.Data.SqlClient;

namespace BLL
{
    public class DeXuat_BLL
    {
        static ThucDon_DAL dalThucdon = new ThucDon_DAL();

        //ThucDon_BLL bllThucDon = new ThucDon_BLL();
        public static bool isVegetarian;
        public static int targetCalories;
        public static int bestPrice;
        //DeXuat_BLL dexuatBll = new DeXuat_BLL();

        public class Menu
        {
            public List<MenuItem> items;
            public Menu()
            {
                items = new List<MenuItem>();
                SqlConnection conn = SqlConnectionData.Connect();
                conn.Open();

                // Tạo câu truy vấn SQL để lấy danh sách các món ăn
                string query = "SELECT * FROM tblMonAn";

                // Tạo đối tượng SqlCommand để thực thi câu truy vấn
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    //List<MenuItem> menuList = new List<MenuItem>();

                    // Thực thi câu truy vấn và đọc dữ liệu từ SqlDataReader
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            MenuItem monan = new MenuItem();
                            //monan.MaMonAn = int.Parse(reader["MaMonAn"].ToString());
                            monan.TenMA = reader["TenMA"].ToString();
                            // monan.LoaiMonAn = reader["LoaiMonAn"].ToString();
                            monan.Calo = int.Parse(reader["Calo"].ToString());
                            monan.DonGia = int.Parse(reader["DonGia"].ToString());
                            string dm = reader["FK_MaDM"].ToString();
                            if (dm == "DM01")
                            {
                                monan.Loai = false;
                            }
                            else if (dm == "DM03")
                            {
                                monan.Loai = true;
                            }

                            items.Add(monan);
                        }
                    }

                }
            }
            public List<MenuItem> GetItems()
            {
                return items;
            }

        }
        class BranchAndBound
        {

            public static List<MenuItem> bestMenu;
            //Menu menu = new Menu();
            //Menu = List<MenuItem>
            public static void FindBestMenu(Menu menu, int calories, bool isVegetarian)
            {
                bestPrice = int.MaxValue;
                bestMenu = new List<MenuItem>();

                FindBestMenuRecursive(menu, calories, isVegetarian, 0, 0, new List<MenuItem>());
            }

            private static void FindBestMenuRecursive(Menu menu, int caloriesRemaining, bool isVegetarian, int priceSoFar, int currentItemIndex, List<MenuItem> currentMenu)
            {
                if (caloriesRemaining <= 0)
                {
                    // We have reached the goal of finding a menu that meets our calorie target
                    if (priceSoFar < bestPrice)
                    {
                        // This is the best menu we have found so far
                        bestPrice = priceSoFar;
                        bestMenu = new List<MenuItem>(currentMenu);
                    }
                    return;
                }

                if (currentItemIndex >= menu.GetItems().Count)
                {
                    // We have reached the end of the menu without finding a valid solution
                    return;
                }

                MenuItem currentItem = menu.GetItems()[currentItemIndex];

                // If this item is not vegetarian and we are looking for vegetarian options, skip it
                if (isVegetarian)
                {
                    if (!currentItem.Loai)
                    {
                        FindBestMenuRecursive(menu, caloriesRemaining, isVegetarian, priceSoFar, currentItemIndex + 1, currentMenu);
                        return;
                    }
                }
                else
                {
                    if (currentItem.Loai)
                    {
                        FindBestMenuRecursive(menu, caloriesRemaining, isVegetarian, priceSoFar, currentItemIndex + 1, currentMenu);
                        return;
                    }
                }

                // If this item has more calories than we have remaining, skip it
                if (currentItem.Calo > caloriesRemaining)
                {
                    FindBestMenuRecursive(menu, caloriesRemaining, isVegetarian, priceSoFar, currentItemIndex + 1, currentMenu);
                    return;
                }

                // Try adding the current item to the menu
                currentMenu.Add(currentItem);
                FindBestMenuRecursive(menu, caloriesRemaining - currentItem.Calo, isVegetarian, priceSoFar + currentItem.DonGia, currentItemIndex + 1, currentMenu);
                currentMenu.RemoveAt(currentMenu.Count - 1);

                // Try skipping the current item
                FindBestMenuRecursive(menu, caloriesRemaining, isVegetarian, priceSoFar, currentItemIndex + 1, currentMenu);

            }

            public static int GetBestPrice()
            {
                return bestPrice;
            }

            public static List<MenuItem> GetBestMenu()
            {
                return bestMenu;
            }
        }

        /* public List<Menu> ok(int calo,string choice)
         {
             Menu menu = new Menu();

             List<Menu> dsMon = new List<Menu>();
             BranchAndBound.FindBestMenu(menu, targetCalories, isVegetarian);
             foreach (MenuItem item in BranchAndBound.GetBestMenu())
             {
                 if (!dsMon.Contains(item.TenMA))
                 {

                     dsMon.Add(item.TenMA);
                 }
             }
             return dsMon;

         }*/
        public int GetBestPrice()
        {
            return bestPrice;
        }
        public List<MenuItem> ok(int targetCalories, bool isVegetarian)
        {
            //DeXuat_DAL.Menu menu = new DeXuat_DAL.Menu();
            Menu menu = new Menu();
            List<MenuItem> dsMon = new List<MenuItem>();

            BranchAndBound.FindBestMenu(menu, targetCalories, isVegetarian);
            foreach (MenuItem item in BranchAndBound.GetBestMenu())
            {
                if (!dsMon.Contains(item))
                {
                    dsMon.Add(item);
                }
            }
            return dsMon;
        }
    }
}