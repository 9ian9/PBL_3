﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class TaiKhoan_DAL : DBconnect
    {  
        DBconnect dah = new DBconnect();
        public static string CheckLogicDTO(TaiKhoan_DTO taikhoan)
        {
            string user = null;
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            SqlCommand command = new SqlCommand("dangnhap", conn);
            command.CommandType = System.Data.CommandType.StoredProcedure;

            command.Parameters.AddWithValue("@user", taikhoan.TaiKhoan);
            command.Parameters.AddWithValue("@pass", taikhoan.MatKhau);
            //  kiem tra quyen
            command.Connection = conn;
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    user = reader.GetString(0);
                    return user;
                }
                reader.Close();
                conn.Close();
            }
            else
            {
                return "Tài khoản hoặc mật khẩu không chính xác";
            }
            return user;
        }
        public DataTable getMaTK()
        {
            string s = "SELECT MaTK FROM tblTaiKhoan";
            return dah.get_DaTaTable(s);
        }
        public string CheckLogic(TaiKhoan_DTO taikhoan)
        {
            string info = CheckLogicDTO(taikhoan);
            return info;
        }
     

    }
    }

