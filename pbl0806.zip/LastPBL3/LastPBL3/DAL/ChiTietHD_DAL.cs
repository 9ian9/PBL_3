﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using DAL;
using System.Data;
using static DAL.DBconnect;
using System.Data.SqlClient;

namespace DAL
{
    public class ChiTietHD_DAL
    {
        DBconnect dah = new DBconnect();
        
        public DataTable LoadCTHD()
        {
            string s = "SELECT TenMA, SoLuong FROM tblChiTietHD";
            return dah.get_DaTaTable(s);
        }
        public DataTable getCTHD(string idh)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            string data = string.Format("SELECT tblMonAn.TenMA, tblChiTietHD.SoLuong, tblChiTietHD.DonGia, tblChiTietHD.ThanhTien FROM tblChiTietHD INNER JOIN tblMonAn ON tblMonAn.TenMA = tblChiTietHD.TenMA AND MaHD = '{0}'", idh);
            SqlDataAdapter da = new SqlDataAdapter(data, conn);
            DataTable dtFood = new DataTable();
            da.Fill(dtFood);
            conn.Close();
            return dtFood;
        }
        public DataTable getTenMA()
        {
            string s = "SELECT * FROM tblChiTietHD";
            return dah.get_DaTaTable(s);
        }
        
        public void insertCTHD(ChiTietHD_DTO cthd)
        {
            dah.thucthi("insert into tblChiTietHD values('" + cthd.MaHD + "','" + cthd.TenMA + "','" + cthd.SoLuong + "','" + cthd.DonGia+"','"+cthd.ThanhTien + "')");
        }
        

        public DataTable List1(string mahd)
        {
      
            string caulenh = "select * from tblChiTietHD where MaHD='" +mahd + "'";
            return dah.get_DaTaTable(caulenh);
        }
        
        public void XoaCTHD(ChiTietHD_DTO cthd)
        {
            dah.thucthi("delete from tblChiTietHD where TenMA= N'" + cthd.TenMA + "'");
        }
       
        public DataTable ThongKeHangBanChay()
        {
            DataTable dt = new DataTable();
            dt = dah.get_DaTaTable("select top (5) tblMonAn.MaMA,tblMonAn.TenMA,sum(tblChiTietHD.SoLuong) [Số lượng bán] from tblMonAn,tblChiTietHD where tblMonAn.TenMA=tblChiTietHD.TenMA group by tblMonAn.MaMA,tblMonAn.TenMA order by [Số lượng bán] desc");
            return dt;
        }
        public DataTable ThongKeHangBanCham()
        {
            DataTable dt = new DataTable();
            dt = dah.get_DaTaTable("select top (5) tblMonAn.MaMA,tblMonAn.TenMA,sum(tblChiTietHD.SoLuong) [Số lượng bán] from tblMonAn,tblChiTietHD where tblMonAn.TenMA=tblChiTietHD.TenMA group by tblMonAn.MaMA,tblMonAn.TenMA order by [Số lượng bán] asc");
            return dt;
        }
       
        public int DemBanGhi(string mahd, string tenma)
        {
            int banghi;
            banghi = dah.TongBanGhi("select * from tblChiTietHD where MaHD='" + mahd + "'and TenMA='" + tenma + "' ");
            return banghi;
        }

    }
}
