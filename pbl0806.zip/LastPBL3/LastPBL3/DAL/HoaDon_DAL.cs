﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;
using static DAL.DBconnect;

namespace DAL
{
    
    public class HoaDon_DAL
    {
        DBconnect dah = new DBconnect();

        public DataTable getHD()
        {
            string s = "SELECT * FROM tblHoaDon";
            return dah.get_DaTaTable(s);
        }
       
        public void Them(HoaDon_DTO hd)
        {
            DateTime ngayban = DateTime.Now;
            string ngaygio = ngayban.Month.ToString() + "/" + ngayban.Day.ToString() + "/" + ngayban.Year.ToString();
              string s = "insert into tblHoaDon values(N'" + hd.MaHD + "',N'" + hd.MaNV + "','" + ngaygio + "','"+hd.TongTien +"')";
        //    string s = "insert into tblHoaDon values('" + hd.MaHD + "','" + hd.MaNV + "','" + ngaygio + "','" + hd.TongTien + "'";
            dah.thucthi(s);
        }
        public void Xoa(HoaDon_DTO hd)
        {
            dah.thucthi("delete from tblHoaDon where MaHD='" + hd.MaHD + "'");
        }
       
        public bool editHD(HoaDon_DTO hd)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            try
            {
                conn.Open();
                string SQL = string.Format("UPDATE tblHoaDon SET TongTien ='{0}' WHERE MaHD = '{1}'",hd.TongTien, hd.MaHD);
             //   string SQL = string.Format("UPDATE tblHoaDon SET NgayBan = '{0}',MaNV ='{1}' WHERE MaHD = '{2}'",hd.NgayBan, hd.MaNV,hd.MaHD);
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception )
            {

            }
            finally
            {
                conn.Close();
            }
            return false;
        }
        public DataTable hd(string mahd)
        {
            string caulenh = "select * from tblHoaDon where MaHD='" + mahd + "'";
            return dah.get_DaTaTable(caulenh);
        }
        public int DemBanGhi(string mahd)
        {
            int banghi;
            banghi = dah.TongBanGhi("select * from tblHoaDon where MaHD='" + mahd + "' ");
            return banghi;
        }

        public DataTable getMaNV()
        {
            string s = "SELECT * FROM tblHoaDon";
            return dah.get_DaTaTable(s);
        }
    }
}
