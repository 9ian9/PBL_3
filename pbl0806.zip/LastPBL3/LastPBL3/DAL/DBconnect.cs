﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography.Pkcs;

namespace DAL
{
    public class DBconnect
    {
        public class SqlConnectionData
        {
            public static SqlConnection Connect()
            {
                // tạo chuỗi kết nối cơ sở dl

               string strcon = @"Data Source=VINSMOKE\SQLEXPRESS;Initial Catalog=PBL3;Integrated Security=True";
               SqlConnection conn = new SqlConnection(strcon); // khoi tao connect
               return conn;
            }
        }
        SqlCommand cmd;
        SqlDataAdapter da;
        // mới thêm

        public void RunSQL(string sql)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();   
        }
        //System.Data.SqlClient.SqlException: 'Invalid column name 'MaMA'.'

        public void thucthi(string sql)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            conn.Open();
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteReader();
            conn.Close();
        }
        public DataTable get_DaTaTable(string clSelect)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            da = new SqlDataAdapter(clSelect, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        public int TongBanGhi(string strSelect)
        {
            SqlConnection conn = SqlConnectionData.Connect();
            DataTable dtTong = new DataTable();
            da = new SqlDataAdapter(strSelect, conn);
            da.Fill(dtTong);
            // 
            int sbg = dtTong.Rows.Count;
            return sbg;

        }


    }

}
